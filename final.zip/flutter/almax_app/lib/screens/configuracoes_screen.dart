import 'package:almax_app/core/api_client.dart';
import 'package:flutter/material.dart';
import '../models/usuario.dart';

class ConfiguracoesScreen extends StatelessWidget {
  const ConfiguracoesScreen({
    super.key,
    required this.usuario,
    required this.temaEscuro,
    required this.onTemaAlterado,
    required this.onLogout,
  });

  final Usuario usuario;
  final bool temaEscuro;
  final ValueChanged<bool> onTemaAlterado;
  final VoidCallback onLogout;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Configurações do Sistema', style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        children: [
          // Card de Perfil do Usuário
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 34,
                    backgroundColor: primary.withAlpha(isDark ? 50 : 25),
                    child: Icon(Icons.person_rounded, size: 38, color: primary),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          usuario.nome,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          usuario.email,
                          style: TextStyle(
                            fontSize: 13,
                            color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: primary.withAlpha(isDark ? 35 : 20),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: primary.withAlpha(80)),
                          ),
                          child: Text(
                            usuario.perfil.toUpperCase(),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: primary,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Seção: Aparência e Cores
          _buildSecaoTitulo('APARÊNCIA E TEMA', isDark),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  secondary: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: primary.withAlpha(isDark ? 35 : 20),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      temaEscuro ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                      color: primary,
                    ),
                  ),
                  title: Text(
                    temaEscuro ? 'Tema Escuro (Laranja & Preto)' : 'Tema Claro (Azul & Branco)',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                  subtitle: Text(
                    temaEscuro
                        ? 'Cores ativas: Preto absoluto com destaques em laranja elétrico.'
                        : 'Cores ativas: Branco suave com azul cobalto vibrante.',
                    style: const TextStyle(fontSize: 12),
                  ),
                  value: temaEscuro,
                  onChanged: onTemaAlterado,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Seção: Conexão e API
          _buildSecaoTitulo('CONEXÃO COM BACKEND', isDark),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.teal.withAlpha(isDark ? 35 : 20),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.dns_rounded, color: Colors.teal, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Servidor API Spring Boot',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              ApiClient.baseUrl,
                              style: const TextStyle(
                                fontSize: 12,
                                fontFamily: 'monospace',
                                color: Colors.teal,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Para testar em Windows/Web use localhost; no emulador Android use 10.0.2.2.',
                    style: TextStyle(
                      fontSize: 11,
                      color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Seção: Sessão e Conta
          _buildSecaoTitulo('SESSÃO E CONTA', isDark),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.red.withAlpha(isDark ? 35 : 20),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.logout_rounded, color: Colors.red, size: 20),
              ),
              title: const Text(
                'Encerrar Sessão',
                style: TextStyle(fontWeight: FontWeight.w700, color: Colors.red),
              ),
              subtitle: const Text('Desconectar sua conta deste dispositivo', style: TextStyle(fontSize: 12)),
              trailing: const Icon(Icons.chevron_right_rounded, color: Colors.red),
              onTap: () {
                showDialog<void>(
                  context: context,
                  builder: (dialogContext) => AlertDialog(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    title: const Text('Sair da conta?'),
                    content: const Text('Deseja realmente encerrar sua sessão e voltar à tela de login?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialogContext),
                        child: const Text('Cancelar'),
                      ),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: Colors.red),
                        onPressed: () {
                          Navigator.pop(dialogContext);
                          onLogout();
                        },
                        child: const Text('Encerrar Sessão'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSecaoTitulo(String titulo, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        titulo,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.8,
          color: isDark ? const Color(0xFF71717A) : const Color(0xFF94A3B8),
        ),
      ),
    );
  }
}
