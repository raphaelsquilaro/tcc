import 'package:almax_app/service/scanner_service.dart';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../models/conferencia.dart';
import './relatorios_screen.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({
    super.key,
    required this.ambienteId,
    required this.ambienteNome,
  });

  final int ambienteId;
  final String ambienteNome;

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final _scanner = MobileScannerController();
  final _service = ScannerService();
  final List<Conferencia> _resultados = [];
  bool _processando = false;
  bool _finalizada = false;
  bool _lanterna = false;
  String _mensagem = 'Aponte a câmera para o QR Code do patrimônio.';

  Future<void> _detectar(BarcodeCapture capture) async {
    if (_processando || _finalizada) return;
    final codigo = capture.barcodes.firstOrNull?.rawValue;
    if (codigo == null || codigo.trim().isEmpty) return;

    setState(() {
      _processando = true;
      _mensagem = 'Validando código $codigo...';
    });

    try {
      final resultado = await _service.validarCodigo(
        codigo: codigo,
        ambienteId: widget.ambienteId,
      );

      if (!mounted) return;
      setState(() {
        _resultados.insert(0, resultado);
        _mensagem = resultado.mensagem ?? 'Leitura processada com sucesso.';
      });
      await _scanner.stop();
    } catch (e) {
      if (mounted) setState(() => _mensagem = 'Erro na validação: $e');
    } finally {
      if (mounted) setState(() => _processando = false);
    }
  }

  Future<void> _proximaLeitura() async {
    setState(() => _mensagem = 'Aponte para o próximo QR Code.');
    await _scanner.start();
  }

  Future<void> _abrirRelatorioPdf() async {
    setState(() => _finalizada = true);
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => RelatorioScreen(
          ambienteNome: widget.ambienteNome,
          resultados: List.unmodifiable(_resultados),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _scanner.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    final conferidos = _resultados.where((r) => r.valida).length;
    final divergencias = _resultados.length - conferidos;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Conferência por QR Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            Text(
              widget.ambienteNome,
              style: TextStyle(
                fontSize: 12,
                color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Lanterna',
            icon: Icon(_lanterna ? Icons.flash_on_rounded : Icons.flash_off_rounded),
            onPressed: () {
              _scanner.toggleTorch();
              setState(() => _lanterna = !_lanterna);
            },
          ),
          IconButton(
            tooltip: 'Inverter câmera',
            icon: const Icon(Icons.flip_camera_ios_rounded),
            onPressed: () => _scanner.switchCamera(),
          ),
        ],
      ),
      body: Column(
        children: [
          // Área da Câmera com Mira Visual
          Expanded(
            flex: 4,
            child: Stack(
              alignment: Alignment.center,
              children: [
                MobileScanner(
                  controller: _scanner,
                  onDetect: _detectar,
                ),
                // Moldura de Mira
                Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    border: Border.all(color: primary.withAlpha(200), width: 2.5),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: primary.withAlpha(60),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        top: 8,
                        left: 8,
                        child: Icon(Icons.crop_free_rounded, color: primary, size: 28),
                      ),
                    ],
                  ),
                ),
                if (_processando)
                  Container(
                    color: Colors.black54,
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(color: primary),
                          const SizedBox(height: 12),
                          const Text(
                            'Processando leitura...',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Informações e Ações
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF121215) : Colors.white,
                border: Border(
                  top: BorderSide(
                    color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
                    width: 1.2,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Status da Mensagem
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: primary.withAlpha(isDark ? 25 : 15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: primary.withAlpha(60)),
                    ),
                    child: Text(
                      _mensagem,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isDark ? const Color(0xFFFAFAFA) : const Color(0xFF0F172A),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Contadores de Leituras
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildMetricChip('Total Lido', '${_resultados.length}', Colors.blue, isDark),
                      _buildMetricChip('Corretos', '$conferidos', Colors.green, isDark),
                      _buildMetricChip('Divergentes', '$divergencias', Colors.redAccent, isDark),
                    ],
                  ),
                  const SizedBox(height: 10),

                  // Lista curta da última leitura
                  Expanded(
                    child: _resultados.isEmpty
                        ? Center(
                            child: Text(
                              'Nenhuma leitura realizada ainda.',
                              style: TextStyle(
                                fontSize: 13,
                                color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                              ),
                            ),
                          )
                        : ListView.builder(
                            itemCount: _resultados.length > 2 ? 2 : _resultados.length,
                            itemBuilder: (context, i) {
                              final r = _resultados[i];
                              return ListTile(
                                dense: true,
                                visualDensity: VisualDensity.compact,
                                leading: Icon(
                                  r.valida ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
                                  color: r.valida ? Colors.green : Colors.red,
                                  size: 20,
                                ),
                                title: Text(
                                  r.produto?.nome ?? r.codigoLido,
                                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                                ),
                                subtitle: Text(
                                  'Patrimônio: ${r.produto?.numeroPatrimonio ?? "—"} • ${r.mensagem ?? ""}',
                                  style: const TextStyle(fontSize: 11),
                                ),
                              );
                            },
                          ),
                  ),

                  // =========================================================
                  // BOTÕES LADO A LADO: LER QR CODE + GERAR RELATÓRIO PDF
                  // =========================================================
                  Row(
                    children: [
                      // Botão 1: Ler Próximo QR Code
                      Expanded(
                        flex: 6,
                        child: SizedBox(
                          height: 48,
                          child: FilledButton.icon(
                            onPressed: _proximaLeitura,
                            icon: const Icon(Icons.qr_code_scanner_rounded, size: 20),
                            label: const Text(
                              'Ler QR Code',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                            ),
                            style: FilledButton.styleFrom(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // Botão 2: Gerar Relatório em PDF
                      Expanded(
                        flex: 5,
                        child: SizedBox(
                          height: 48,
                          child: OutlinedButton.icon(
                            onPressed: _resultados.isEmpty ? null : _abrirRelatorioPdf,
                            icon: const Icon(Icons.picture_as_pdf_rounded, size: 20),
                            label: const Text(
                              'Gerar PDF',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                            ),
                            style: OutlinedButton.styleFrom(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricChip(String label, String value, Color color, bool isDark) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: color.withAlpha(isDark ? 30 : 15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(80)),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: color),
          ),
          Text(
            label,
            style: TextStyle(fontSize: 10, color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B)),
          ),
        ],
      ),
    );
  }
}
