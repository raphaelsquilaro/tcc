import 'package:almax_app/service/produto_service.dart';
import 'package:almax_app/service/relatorio_service.dart';
import 'package:flutter/material.dart';
import '../models/conferencia.dart';
import '../models/produto.dart';
import 'scanner_screen.dart';

class ProdutosScreen extends StatefulWidget {
  const ProdutosScreen({
    super.key,
    required this.ambienteId,
    required this.ambienteNome,
  });

  final int ambienteId;
  final String ambienteNome;

  @override
  State<ProdutosScreen> createState() => _ProdutosScreenState();
}

class _ProdutosScreenState extends State<ProdutosScreen> {
  final _service = ProdutoService();
  final _relatorioService = RelatorioService();
  late Future<List<Produto>> _future;
  String _filtro = '';
  bool _gerandoPdf = false;

  @override
  void initState() {
    super.initState();
    _recarregar();
  }

  void _recarregar() {
    setState(() {
      _future = _service.listarPorAmbiente(widget.ambienteId);
    });
  }

  void _abrirScanner(List<Produto> produtos) async {
    final resultados = await Navigator.push<List<Conferencia>>(
      context,
      MaterialPageRoute(
        builder: (_) => ScannerScreen(
          ambienteId: widget.ambienteId,
          ambienteNome: widget.ambienteNome,
        ),
      ),
    );
    if (!mounted || resultados == null) return;

    final conferidos = resultados.where((r) => r.valida).length;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_rounded, color: Colors.white),
            const SizedBox(width: 10),
            Text('$conferidos ativo(s) conferido(s) nesta sessão.'),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _gerarPdf(List<Produto> produtos) async {
    if (_gerandoPdf) return;
    setState(() => _gerandoPdf = true);

    try {
      await _relatorioService.gerarRelatorioProdutos(
        ambienteNome: widget.ambienteNome,
        produtos: produtos,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao gerar PDF: $e'),
            backgroundColor: Colors.red.shade700,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _gerandoPdf = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.ambienteNome,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
            ),
            Text(
              'Ambiente #${widget.ambienteId} • Controle de Ativos',
              style: TextStyle(
                fontSize: 12,
                color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Atualizar',
            onPressed: _recarregar,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: FutureBuilder<List<Produto>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    strokeWidth: 3,
                    color: primary,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Carregando produtos do ambiente...',
                    style: TextStyle(
                      color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline_rounded, size: 56, color: theme.colorScheme.error),
                    const SizedBox(height: 16),
                    Text(
                      'Erro ao carregar produtos',
                      style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${snapshot.error}',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B)),
                    ),
                    const SizedBox(height: 20),
                    FilledButton.icon(
                      onPressed: _recarregar,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Tentar novamente'),
                    ),
                  ],
                ),
              ),
            );
          }

          final todosProdutos = snapshot.data ?? [];
          final produtosFiltrados = todosProdutos.where((p) {
            if (_filtro.trim().isEmpty) return true;
            final termo = _filtro.toLowerCase();
            return p.nome.toLowerCase().contains(termo) ||
                p.numeroPatrimonio.toLowerCase().contains(termo) ||
                (p.marca?.toLowerCase().contains(termo) ?? false) ||
                (p.status?.toLowerCase().contains(termo) ?? false);
          }).toList();

          return Column(
            children: [
              // Barra de Busca e Indicadores
              Container(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF121215) : Colors.white,
                  border: Border(
                    bottom: BorderSide(
                      color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
                      width: 1,
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    // Campo de pesquisa
                    TextField(
                      decoration: InputDecoration(
                        hintText: 'Buscar por nome, patrimônio ou marca...',
                        prefixIcon: const Icon(Icons.search_rounded, size: 22),
                        isDense: true,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        suffixIcon: _filtro.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear_rounded, size: 18),
                                onPressed: () => setState(() => _filtro = ''),
                              )
                            : null,
                      ),
                      onChanged: (v) => setState(() => _filtro = v),
                    ),
                    const SizedBox(height: 10),
                    // Indicadores
                    Row(
                      children: [
                        _buildStatusBadge(
                          icon: Icons.inventory_2_rounded,
                          label: 'Total: ${todosProdutos.length}',
                          color: primary,
                          isDark: isDark,
                        ),
                        const SizedBox(width: 8),
                        _buildStatusBadge(
                          icon: Icons.check_circle_rounded,
                          label: 'Ativos: ${todosProdutos.where((p) => (p.status ?? '').toUpperCase() == 'ATIVO').length}',
                          color: Colors.green,
                          isDark: isDark,
                        ),
                        const SizedBox(width: 8),
                        _buildStatusBadge(
                          icon: Icons.build_circle_rounded,
                          label: 'Manutenção: ${todosProdutos.where((p) => (p.status ?? '').toUpperCase() == 'MANUTENCAO').length}',
                          color: Colors.orange,
                          isDark: isDark,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Lista de Produtos
              Expanded(
                child: produtosFiltrados.isEmpty
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(32),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _filtro.isEmpty ? Icons.inventory_2_outlined : Icons.search_off_rounded,
                                size: 64,
                                color: isDark ? const Color(0xFF3F3F46) : const Color(0xFFCBD5E1),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                _filtro.isEmpty
                                    ? 'Nenhum ativo cadastrado neste ambiente.'
                                    : 'Nenhum resultado para "$_filtro".',
                                textAlign: TextAlign.center,
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
                        itemCount: produtosFiltrados.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, index) {
                          final p = produtosFiltrados[index];
                          return _buildProdutoCard(p, isDark, primary);
                        },
                      ),
              ),
            ],
          );
        },
      ),

      // =====================================================================
      // BOTÕES DE AÇÃO: LER QR CODE + RELATÓRIO PDF LADO A LADO
      // =====================================================================
      bottomSheet: FutureBuilder<List<Produto>>(
        future: _future,
        builder: (context, snapshot) {
          final produtos = snapshot.data ?? [];
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF121215) : Colors.white,
              border: Border(
                top: BorderSide(
                  color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
                  width: 1.2,
                ),
              ),
              boxShadow: [
                BoxShadow(
                  color: isDark ? Colors.black45 : const Color(0x1A0D47A1),
                  blurRadius: 16,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  // Botão 1: Ler QR Code
                  Expanded(
                    flex: 6,
                    child: SizedBox(
                      height: 50,
                      child: FilledButton.icon(
                        onPressed: produtos.isEmpty ? null : () => _abrirScanner(produtos),
                        icon: const Icon(Icons.qr_code_scanner_rounded, size: 22),
                        label: const Text(
                          'Ler QR Code',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                        style: FilledButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Botão 2: Relatório em PDF (AO LADO DO LER QR CODE)
                  Expanded(
                    flex: 5,
                    child: SizedBox(
                      height: 50,
                      child: OutlinedButton.icon(
                        onPressed: _gerandoPdf || produtos.isEmpty ? null : () => _gerarPdf(produtos),
                        icon: _gerandoPdf
                            ? SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: primary,
                                ),
                              )
                            : const Icon(Icons.picture_as_pdf_rounded, size: 22),
                        label: Text(
                          _gerandoPdf ? 'Gerando...' : 'Relatório PDF',
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                        ),
                        style: OutlinedButton.styleFrom(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusBadge({
    required IconData icon,
    required String label,
    required Color color,
    required bool isDark,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(isDark ? 35 : 20),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(70)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProdutoCard(Produto p, bool isDark, Color primary) {
    final statusColor = (p.status ?? '').toUpperCase() == 'ATIVO'
        ? Colors.green
        : (p.status ?? '').toUpperCase() == 'MANUTENCAO'
            ? Colors.orange
            : Colors.grey;

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _mostrarDetalhesModal(p),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: primary.withAlpha(isDark ? 35 : 20),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.inventory_2_rounded, color: primary, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          p.nome,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        if (p.marca != null || p.modelo != null)
                          Text(
                            [p.marca, p.modelo].where((s) => s != null && s.isNotEmpty).join(' • '),
                            style: TextStyle(
                              fontSize: 13,
                              color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                            ),
                          ),
                      ],
                    ),
                  ),
                  // Status Pill
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withAlpha(isDark ? 40 : 25),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: statusColor.withAlpha(90)),
                    ),
                    child: Text(
                      (p.status ?? 'INDEFINIDO').toUpperCase(),
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: statusColor,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.qr_code_2_rounded, size: 16, color: Colors.grey),
                      const SizedBox(width: 6),
                      Text(
                        'Patrimônio: ${p.numeroPatrimonio.isEmpty ? "—" : p.numeroPatrimonio}',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                  if (p.tagEpc != null && p.tagEpc!.isNotEmpty)
                    Row(
                      children: [
                        const Icon(Icons.nfc_rounded, size: 16, color: Colors.blue),
                        const SizedBox(width: 4),
                        Text(
                          'RFID Ativo',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: isDark ? const Color(0xFF93C5FD) : const Color(0xFF1D4ED8),
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _mostrarDetalhesModal(Produto p) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF3F3F46) : const Color(0xFFCBD5E1),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text(
              p.nome,
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              'Patrimônio nº ${p.numeroPatrimonio}',
              style: TextStyle(
                color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                fontFamily: 'monospace',
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 12),
            _buildDetalheLinha('Marca:', p.marca ?? '—'),
            _buildDetalheLinha('Modelo:', p.modelo ?? '—'),
            _buildDetalheLinha('Nº de Série:', p.numeroSerie ?? '—'),
            _buildDetalheLinha('Status:', p.status ?? '—'),
            _buildDetalheLinha('Tag RFID / EPC:', p.tagEpc ?? 'Nenhuma tag vinculada'),
            if (p.descricao != null && p.descricao!.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                'Descrição:',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                ),
              ),
              const SizedBox(height: 4),
              Text(p.descricao!, style: const TextStyle(fontSize: 14)),
            ],
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fechar'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetalheLinha(String rotulo, String valor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(rotulo, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          Text(valor, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }
}
