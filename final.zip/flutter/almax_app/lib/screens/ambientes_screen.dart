
import 'package:almax_app/service/ambiente_service.dart';
import 'package:flutter/material.dart';
import '../models/ambiente.dart';
import 'produtos_screen.dart';

class AmbientesScreen extends StatefulWidget {
  const AmbientesScreen({super.key});

  @override
  State<AmbientesScreen> createState() => _AmbientesScreenState();
}

class _AmbientesScreenState extends State<AmbientesScreen> {
  final _ambientes = AmbienteService();
  late Future<List<Ambiente>> _future;

  @override
  void initState() {
    super.initState();
    _future = _ambientes.listar();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ambientes'),
      ),
      body: FutureBuilder<List<Ambiente>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Text(
                  'Não foi possível carregar os ambientes.\n'
                  '${snapshot.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final lista = snapshot.data ?? <Ambiente>[];

          if (lista.isEmpty) {
            return const Center(
              child: Text('Nenhum ambiente cadastrado.'),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: lista.length,
            itemBuilder: (context, index) {
              final ambiente = lista[index];

              return Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.business),
                  ),
                  title: Text(ambiente.nome),
                  subtitle: Text(
                    '${ambiente.descricao}\n'
                    'Produtos: ${ambiente.quantidadeProdutos}',
                  ),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProdutosScreen(
                          ambienteId: ambiente.id,
                          ambienteNome: ambiente.nome,
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
