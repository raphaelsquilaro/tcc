import 'package:almax_app/service/relatorio_service.dart';
import 'package:flutter/material.dart';
import '../models/conferencia.dart';

class RelatorioScreen extends StatelessWidget {
  RelatorioScreen({
    super.key,
    required this.ambienteNome,
    required this.resultados,
  });

  final String ambienteNome;
  final List<Conferencia> resultados;
  final RelatorioService _service = RelatorioService();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    final conferidos = resultados.where((r) => r.resultado == ResultadoConferencia.conferido).length;
    final divergencias = resultados.length - conferidos;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Resumo da Auditoria', style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: Column(
        children: [
          // Banner de Cabeçalho
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF121215) : Colors.white,
              border: Border(
                bottom: BorderSide(
                  color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
                  width: 1,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Ambiente Auditado',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          ambienteNome,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: primary.withAlpha(isDark ? 35 : 20),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.event_note_rounded, size: 16, color: primary),
                          const SizedBox(width: 6),
                          Text(
                            'Hoje',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Cards de contagem
                Row(
                  children: [
                    _buildStatCard('Total Lido', '${resultados.length}', Icons.qr_code_rounded, Colors.blue, isDark),
                    const SizedBox(width: 10),
                    _buildStatCard('Conferidos', '$conferidos', Icons.check_circle_rounded, Colors.green, isDark),
                    const SizedBox(width: 10),
                    _buildStatCard('Divergências', '$divergencias', Icons.warning_amber_rounded, Colors.redAccent, isDark),
                  ],
                ),
              ],
            ),
          ),

          // Título da listagem
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Detalhamento das Leituras',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                Text(
                  '${resultados.length} registro(s)',
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          ),

          // Lista de Resultados
          Expanded(
            child: resultados.isEmpty
                ? const Center(child: Text('Nenhum registro para exibir.'))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                    itemCount: resultados.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final r = resultados[i];
                      final isOk = r.valida;
                      final cardColor = isOk ? Colors.green : Colors.red;

                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Container(
                                width: 38,
                                height: 38,
                                decoration: BoxDecoration(
                                  color: cardColor.withAlpha(isDark ? 35 : 20),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Icon(
                                  isOk ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                                  color: cardColor,
                                  size: 22,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      r.produto?.nome ?? r.codigoLido,
                                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Patrimônio: ${r.produto?.numeroPatrimonio ?? "—"} • Código: ${r.codigoLido}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontFamily: 'monospace',
                                        color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                                      ),
                                    ),
                                    if (r.mensagem != null)
                                      Text(
                                        r.mensagem!,
                                        style: TextStyle(fontSize: 11, color: cardColor),
                                      ),
                                  ],
                                ),
                              ),
                              Text(
                                '${r.dataHora.hour.toString().padLeft(2, '0')}:${r.dataHora.minute.toString().padLeft(2, '0')}',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),

      // Botão Flutuante de Exportação
      bottomSheet: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF121215) : Colors.white,
          border: Border(
            top: BorderSide(
              color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
              width: 1.2,
            ),
          ),
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 52,
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => _service.gerarRelatorio(ambienteNome: ambienteNome, resultados: resultados),
              icon: const Icon(Icons.picture_as_pdf_rounded, size: 22),
              label: const Text(
                'Exportar Relatório em PDF',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              style: FilledButton.styleFrom(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color, bool isDark) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: color.withAlpha(isDark ? 30 : 15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withAlpha(60)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color),
            ),
            Text(
              label,
              style: TextStyle(fontSize: 11, color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B)),
            ),
          ],
        ),
      ),
    );
  }
}
