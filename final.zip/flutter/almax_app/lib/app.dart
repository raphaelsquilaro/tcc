import 'package:almax_app/core/app_theme.dart';
import 'package:almax_app/models/ambiente.dart';
import 'package:almax_app/service/ambiente_service.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/usuario.dart';
import 'screens/login_screen.dart';
import 'screens/configuracoes_screen.dart';
import 'screens/produtos_screen.dart';
import 'core/session_manager.dart';

class InventarioApp extends StatefulWidget {
  const InventarioApp({super.key});
  @override
  State<InventarioApp> createState() => _InventarioAppState();
}

class _InventarioAppState extends State<InventarioApp> {
  Usuario? _usuario;
  bool _temaEscuro = false;
  int _aba = 0;

  @override
  void initState() {
    super.initState();
    _carregarPreferencias();
  }

  Future<void> _carregarPreferencias() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _temaEscuro = prefs.getBool('tema_escuro') ?? false;
      _usuario = null;
    });
  }

  Future<void> _alterarTema(bool valor) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tema_escuro', valor);
    if (mounted) setState(() => _temaEscuro = valor);
  }

  void _login(Usuario usuario) => setState(() {
        _usuario = usuario;
        _aba = 0;
      });

  Future<void> _logout() async {
    await SessionManager.instance.encerrar();
    if (mounted) setState(() => _usuario = null);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Almax • Controle Patrimonial',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: _temaEscuro ? ThemeMode.dark : ThemeMode.light,
        home: _usuario == null
            ? LoginScreen(onLogin: _login)
            : _HomeScreen(
                usuario: _usuario!,
                aba: _aba,
                onAba: (v) => setState(() => _aba = v),
                temaEscuro: _temaEscuro,
                onTema: _alterarTema,
                onLogout: _logout,
              ),
      );
}

class _HomeScreen extends StatefulWidget {
  const _HomeScreen({
    required this.usuario,
    required this.aba,
    required this.onAba,
    required this.temaEscuro,
    required this.onTema,
    required this.onLogout,
  });

  final Usuario usuario;
  final int aba;
  final ValueChanged<int> onAba;
  final bool temaEscuro;
  final ValueChanged<bool> onTema;
  final VoidCallback onLogout;

  @override
  State<_HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<_HomeScreen> {
  final _ambientes = AmbienteService();
  late Future<List<Ambiente>> _future;
  String _filtro = '';

  @override
  void initState() {
    super.initState();
    _recarregar();
  }

  void _recarregar() {
    setState(() {
      _future = _ambientes.listar();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    final pages = [
      Scaffold(
        appBar: AppBar(
          title: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: isDark
                        ? [const Color(0xFFFF6D00), const Color(0xFFFF9E40)]
                        : [const Color(0xFF0D47A1), const Color(0xFF0284C7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.inventory_2_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Ambientes Cadastrados',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                  ),
                  Text(
                    'Olá, ${widget.usuario.nome.split(" ").first}',
                    style: TextStyle(
                      fontSize: 12,
                      color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Atualizar',
              icon: const Icon(Icons.refresh_rounded),
              onPressed: _recarregar,
            ),
          ],
        ),
        body: RefreshIndicator(
          onRefresh: () async => _recarregar(),
          child: FutureBuilder<List<Ambiente>>(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: primary, strokeWidth: 3),
                      const SizedBox(height: 16),
                      Text(
                        'Carregando ambientes da API...',
                        style: TextStyle(
                          color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                        ),
                      ),
                    ],
                  ),
                );
              }

              if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.error_outline_rounded, size: 56, color: theme.colorScheme.error),
                        const SizedBox(height: 16),
                        Text(
                          'Erro ao carregar ambientes',
                          style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${snapshot.error}',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 20),
                        FilledButton.icon(
                          onPressed: _recarregar,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Tentar novamente'),
                        ),
                      ],
                    ),
                  ),
                );
              }

              final todosAmbientes = snapshot.data ?? [];
              final ambientesFiltrados = todosAmbientes.where((a) {
                if (_filtro.trim().isEmpty) return true;
                final termo = _filtro.toLowerCase();
                return a.nome.toLowerCase().contains(termo) ||
                    a.descricao.toLowerCase().contains(termo);
              }).toList();

              return Column(
                children: [
                  // Barra de Busca e Métricas
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF121215) : Colors.white,
                      border: Border(
                        bottom: BorderSide(
                          color: isDark ? const Color(0xFF27272A) : const Color(0xFFE2E8F0),
                          width: 1,
                        ),
                      ),
                    ),
                    child: Column(
                      children: [
                        TextField(
                          decoration: InputDecoration(
                            hintText: 'Filtrar ambiente por nome ou descrição...',
                            prefixIcon: const Icon(Icons.search_rounded, size: 22),
                            isDense: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            suffixIcon: _filtro.isNotEmpty
                                ? IconButton(
                                    icon: const Icon(Icons.clear_rounded, size: 18),
                                    onPressed: () => setState(() => _filtro = ''),
                                  )
                                : null,
                          ),
                          onChanged: (v) => setState(() => _filtro = v),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _buildInfoChip(
                              icon: Icons.meeting_room_rounded,
                              label: 'Total: ${todosAmbientes.length}',
                              color: primary,
                              isDark: isDark,
                            ),
                            const SizedBox(width: 8),
                            _buildInfoChip(
                              icon: Icons.check_circle_rounded,
                              label: 'Ativos: ${todosAmbientes.where((a) => a.ativo).length}',
                              color: Colors.green,
                              isDark: isDark,
                            ),
                            const SizedBox(width: 8),
                            _buildInfoChip(
                              icon: Icons.remove_circle_outline_rounded,
                              label: 'Inativos: ${todosAmbientes.where((a) => !a.ativo).length}',
                              color: Colors.grey,
                              isDark: isDark,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Lista de Ambientes
                  Expanded(
                    child: ambientesFiltrados.isEmpty
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(32),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.business_outlined,
                                    size: 64,
                                    color: isDark ? const Color(0xFF3F3F46) : const Color(0xFFCBD5E1),
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    _filtro.isEmpty
                                        ? 'Nenhum ambiente cadastrado.'
                                        : 'Nenhum ambiente encontrado para "$_filtro".',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.all(16),
                            itemCount: ambientesFiltrados.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 12),
                            itemBuilder: (_, i) {
                              final a = ambientesFiltrados[i];
                              return _buildAmbienteCard(a, isDark, primary);
                            },
                          ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
      ConfiguracoesScreen(
        usuario: widget.usuario,
        temaEscuro: widget.temaEscuro,
        onTemaAlterado: widget.onTema,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      body: pages[widget.aba],
      bottomNavigationBar: NavigationBar(
        selectedIndex: widget.aba,
        onDestinationSelected: widget.onAba,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.meeting_room_outlined),
            selectedIcon: Icon(Icons.meeting_room_rounded),
            label: 'Ambientes',
          ),
          NavigationDestination(
            icon: Icon(Icons.tune_outlined),
            selectedIcon: Icon(Icons.tune_rounded),
            label: 'Configurações',
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required Color color,
    required bool isDark,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(isDark ? 30 : 15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAmbienteCard(Ambiente a, bool isDark, Color primary) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProdutosScreen(
                ambienteId: a.id,
                ambienteNome: a.nome,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: primary.withAlpha(isDark ? 40 : 20),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.meeting_room_rounded, color: primary, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          a.nome,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (a.descricao.isNotEmpty) ...[
                          const SizedBox(height: 3),
                          Text(
                            a.descricao,
                            style: TextStyle(
                              fontSize: 13,
                              color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  // Status Pill
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: a.ativo
                          ? Colors.green.withAlpha(isDark ? 40 : 20)
                          : Colors.grey.withAlpha(isDark ? 40 : 20),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: a.ativo
                            ? Colors.green.withAlpha(80)
                            : Colors.grey.withAlpha(80),
                      ),
                    ),
                    child: Text(
                      a.ativo ? 'ATIVO' : 'INATIVO',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: a.ativo ? Colors.green : Colors.grey,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const Divider(),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      _buildContadorBadge(
                        icon: Icons.inventory_2_outlined,
                        texto: '${a.quantidadeProdutos} produtos',
                        primary: primary,
                        isDark: isDark,
                      ),
                      const SizedBox(width: 8),
                      _buildContadorBadge(
                        icon: Icons.sensors_rounded,
                        texto: '${a.quantidadeLeitores} leitores RFID',
                        primary: primary,
                        isDark: isDark,
                      ),
                    ],
                  ),
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 14,
                    color: isDark ? const Color(0xFF71717A) : const Color(0xFF94A3B8),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContadorBadge({
    required IconData icon,
    required String texto,
    required Color primary,
    required bool isDark,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF27272A) : const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: isDark ? const Color(0xFFA1A1AA) : const Color(0xFF64748B)),
          const SizedBox(width: 4),
          Text(
            texto,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: isDark ? const Color(0xFFE4E4E7) : const Color(0xFF334155),
            ),
          ),
        ],
      ),
    );
  }
}
