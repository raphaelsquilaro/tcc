
import 'package:almax_app/core/api_client.dart';
import 'package:almax_app/models/ambiente.dart';

class AmbienteService {
  Future<List<Ambiente>> listar() async {
    final data = await ApiClient.get('/ambientes');

    if (data is! List) {
      throw Exception(
        'A API não retornou uma lista de ambientes.',
      );
    }

    return data.map((item) {
      return Ambiente.fromJson(
        Map<String, dynamic>.from(item as Map),
      );
    }).toList();
  }
}
