import '../models/conferencia.dart';
import '../models/produto.dart';
import 'produto_service.dart';

/// O backend atual não possui endpoint de sessão/conferência de inventário.
/// Este serviço valida os produtos consultados pela API e mantém os resultados
/// somente na memória do app. Para auditoria, implemente persistência no backend.
class ScannerService {
  ScannerService({ProdutoService? produtoService})
      : _produtoService = produtoService ?? ProdutoService();

  final ProdutoService _produtoService;
  final Set<int> _idsConferidos = {};

  Future<Conferencia> validarCodigo({
    required String codigo,
    required int ambienteId,
  }) async {
    final produtos = await _produtoService.listarTodos();
    final normalized = codigo.trim().toLowerCase();

    Produto? produto;
    for (final item in produtos) {
      if (item.numeroPatrimonio.trim().toLowerCase() == normalized ||
          (item.tagEpc?.trim().toLowerCase() == normalized)) {
        produto = item;
        break;
      }
    }

    if (produto == null) {
      return Conferencia(
        codigoLido: codigo,
        dataHora: DateTime.now(),
        resultado: ResultadoConferencia.codigoNaoEncontrado,
        mensagem: 'Código não corresponde a patrimônio ou EPC cadastrado.',
      );
    }

    if (produto.ambienteId != ambienteId) {
      return Conferencia(
        codigoLido: codigo,
        dataHora: DateTime.now(),
        resultado: ResultadoConferencia.ambienteDivergente,
        produto: produto,
        mensagem: 'O ativo está cadastrado em outro ambiente.',
      );
    }

    if (!_idsConferidos.add(produto.id)) {
      return Conferencia(
        codigoLido: codigo,
        dataHora: DateTime.now(),
        resultado: ResultadoConferencia.duplicado,
        produto: produto,
        mensagem: 'Este ativo já foi conferido nesta sessão.',
      );
    }

    return Conferencia(
      codigoLido: codigo,
      dataHora: DateTime.now(),
      resultado: ResultadoConferencia.conferido,
      produto: produto,
      mensagem: 'Ativo conferido com sucesso.',
    );
  }

  void limparSessao() => _idsConferidos.clear();
}
