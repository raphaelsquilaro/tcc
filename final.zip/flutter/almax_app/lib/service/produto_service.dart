import '../core/api_client.dart';
import '../models/produto.dart';

class ProdutoService {
  Future<List<Produto>> listarTodos() async {
    final data = await ApiClient.get('/produtos');
    if (data is! List) throw ApiException('Resposta inesperada da API de produtos.');
    return data
        .map((item) => Produto.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
  }

  Future<List<Produto>> listarPorAmbiente(int ambienteId) async {
    final produtos = await listarTodos();
    return produtos.where((p) => p.ambienteId == ambienteId).toList();
  }

  Future<Produto> buscarPorId(int id) async {
    final data = await ApiClient.get('/produtos/$id');
    return Produto.fromJson(Map<String, dynamic>.from(data as Map));
  }
}
