import 'package:almax_app/core/api_client.dart';
import 'package:almax_app/core/session_manager.dart';
import 'package:almax_app/models/usuario.dart';

class AuthService {
  Future<Usuario> login(String email, String senha) async {
    final resposta = await ApiClient.post(
      '/auth/login',
      body: {'email': email, 'senha': senha},
    );

    if (resposta is! Map) {
      throw Exception('Resposta de login inválida.');
    }

    final dados = Map<String, dynamic>.from(resposta);
    final usuarioJson = dados['usuario'] is Map
        ? Map<String, dynamic>.from(dados['usuario'])
        : dados;

    if (usuarioJson['id'] == null || usuarioJson['email'] == null) {
      throw Exception('A API não retornou os dados do usuário.');
    }

    final usuario = Usuario.fromJson(usuarioJson);
    await SessionManager.instance.salvarUsuario(usuario);

    final token = dados['token'];
    if (token is String && token.isNotEmpty) {
      await SessionManager.instance.salvarToken(token);
    }

    return usuario;
  }

  Future<void> logout() async {
    await SessionManager.instance.encerrar();
  }
}
