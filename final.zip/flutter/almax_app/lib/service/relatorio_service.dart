import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/conferencia.dart';
import '../models/produto.dart';

class RelatorioService {
  /// Gera relatório em PDF a partir da lista de produtos cadastrados no ambiente.
  Future<void> gerarRelatorioProdutos({
    required String ambienteNome,
    required List<Produto> produtos,
  }) async {
    final doc = pw.Document();
    final dataHora = DateTime.now();
    final dataStr =
        '${dataHora.day.toString().padLeft(2, '0')}/${dataHora.month.toString().padLeft(2, '0')}/${dataHora.year} às ${dataHora.hour.toString().padLeft(2, '0')}:${dataHora.minute.toString().padLeft(2, '0')}';

    final total = produtos.length;
    final ativos = produtos.where((p) => (p.status ?? '').toUpperCase() == 'ATIVO').length;
    final manutencao = produtos.where((p) => (p.status ?? '').toUpperCase() == 'MANUTENCAO').length;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (context) => _buildHeader('Inventário de Ativos por Ambiente', ambienteNome, dataStr),
        footer: (context) => _buildFooter(context),
        build: (context) => [
          pw.SizedBox(height: 12),
          // Resumo estatístico
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              borderRadius: pw.BorderRadius.circular(8),
              border: pw.Border.all(color: PdfColors.grey300),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('Total de Ativos', '$total'),
                _buildStatItem('Em Operação (Ativo)', '$ativos'),
                _buildStatItem('Em Manutenção', '$manutencao'),
                _buildStatItem('Outros/Inativos', '${total - ativos - manutencao}'),
              ],
            ),
          ),
          pw.SizedBox(height: 16),
          // Tabela de Produtos
          if (produtos.isEmpty)
            pw.Center(
              child: pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 32),
                child: pw.Text(
                  'Nenhum ativo patrimonial cadastrado neste ambiente.',
                  style: pw.TextStyle(color: PdfColors.grey700, fontStyle: pw.FontStyle.italic),
                ),
              ),
            )
          else
            pw.TableHelper.fromTextArray(
              border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 10),
              headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFF0F172A)),
              headerAlignment: pw.Alignment.centerLeft,
              cellAlignment: pw.Alignment.centerLeft,
              cellStyle: const pw.TextStyle(fontSize: 9),
              cellPadding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              rowDecoration: const pw.BoxDecoration(color: PdfColors.white),
              oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF8FAFC)),
              headers: ['Patrimônio', 'Descrição do Ativo', 'Marca / Modelo', 'Tag RFID / EPC', 'Status'],
              data: produtos.map((p) => [
                p.numeroPatrimonio.isEmpty ? '—' : p.numeroPatrimonio,
                p.nome,
                [p.marca, p.modelo].where((s) => s != null && s.isNotEmpty).join(' - ').ifEmpty('—'),
                (p.tagEpc != null && p.tagEpc!.isNotEmpty) ? p.tagEpc! : '—',
                p.status ?? '—',
              ]).toList(),
            ),
        ],
      ),
    );

    await Printing.layoutPdf(
      name: 'relatorio_ativos_${ambienteNome.replaceAll(' ', '_')}.pdf',
      onLayout: (_) async => doc.save(),
    );
  }

  /// Gera relatório a partir dos resultados de conferência (Scanner QR Code)
  Future<void> gerarRelatorio({
    required String ambienteNome,
    required List<Conferencia> resultados,
  }) async {
    final doc = pw.Document();
    final dataHora = DateTime.now();
    final dataStr =
        '${dataHora.day.toString().padLeft(2, '0')}/${dataHora.month.toString().padLeft(2, '0')}/${dataHora.year} às ${dataHora.hour.toString().padLeft(2, '0')}:${dataHora.minute.toString().padLeft(2, '0')}';

    final conferidos = resultados.where((r) => r.valida).length;
    final divergencias = resultados.length - conferidos;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (context) => _buildHeader('Conferência de Inventário (Auditoria)', ambienteNome, dataStr),
        footer: (context) => _buildFooter(context),
        build: (context) => [
          pw.SizedBox(height: 12),
          // Resumo estatístico
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              borderRadius: pw.BorderRadius.circular(8),
              border: pw.Border.all(color: PdfColors.grey300),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('Total Lido', '${resultados.length}'),
                _buildStatItem('Conferidos OK', '$conferidos', color: PdfColors.green800),
                _buildStatItem('Divergências', '$divergencias', color: divergencias > 0 ? PdfColors.red800 : PdfColors.grey800),
              ],
            ),
          ),
          pw.SizedBox(height: 16),
          // Tabela
          if (resultados.isEmpty)
            pw.Center(
              child: pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 32),
                child: pw.Text('Nenhuma leitura registrada nesta sessão de conferência.'),
              ),
            )
          else
            pw.TableHelper.fromTextArray(
              border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white, fontSize: 10),
              headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFF0F172A)),
              cellStyle: const pw.TextStyle(fontSize: 9),
              cellPadding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF8FAFC)),
              headers: ['Código Lido', 'Patrimônio', 'Ativo Identificado', 'Resultado', 'Horário'],
              data: resultados.map((r) => [
                r.codigoLido,
                r.produto?.numeroPatrimonio ?? '—',
                r.produto?.nome ?? 'Não localizado',
                r.resultado == ResultadoConferencia.conferido
                    ? 'CONFERIDO'
                    : r.resultado == ResultadoConferencia.ambienteDivergente
                        ? 'OUTRO AMBIENTE'
                        : r.resultado == ResultadoConferencia.duplicado
                            ? 'DUPLICADO'
                            : 'NÃO ENCONTRADO',
                '${r.dataHora.hour.toString().padLeft(2, '0')}:${r.dataHora.minute.toString().padLeft(2, '0')}:${r.dataHora.second.toString().padLeft(2, '0')}',
              ]).toList(),
            ),
        ],
      ),
    );

    await Printing.layoutPdf(
      name: 'conferencia_${ambienteNome.replaceAll(' ', '_')}.pdf',
      onLayout: (_) async => doc.save(),
    );
  }

  pw.Widget _buildHeader(String titulo, String ambiente, String data) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'ALMAX • CONTROLE PATRIMONIAL',
                  style: pw.TextStyle(
                    fontSize: 16,
                    fontWeight: pw.FontWeight.bold,
                    color: const PdfColor.fromInt(0xFF0284C7),
                  ),
                ),
                pw.SizedBox(height: 2),
                pw.Text(
                  titulo,
                  style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold),
                ),
              ],
            ),
            pw.Container(
              padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: pw.BoxDecoration(
                color: const PdfColor.fromInt(0xFFF1F5F9),
                borderRadius: pw.BorderRadius.circular(6),
                border: pw.Border.all(color: const PdfColor.fromInt(0xFFCBD5E1)),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('Ambiente: $ambiente', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10)),
                  pw.Text('Emissão: $data', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
                ],
              ),
            ),
          ],
        ),
        pw.Divider(thickness: 1, color: const PdfColor.fromInt(0xFFCBD5E1)),
      ],
    );
  }

  pw.Widget _buildFooter(pw.Context context) {
    return pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 10),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Sistema Almax Patrimônio — Relatório Oficial Gerado Eletronicamente',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
          ),
          pw.Text(
            'Página ${context.pageNumber} de ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildStatItem(String label, String value, {PdfColor color = PdfColors.black}) {
    return pw.Column(
      children: [
        pw.Text(value, style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: color)),
        pw.SizedBox(height: 2),
        pw.Text(label, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
      ],
    );
  }
}

extension _StringExt on String {
  String ifEmpty(String fallback) => trim().isEmpty ? fallback : this;
}
