import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/usuario.dart';

/// Guarda a representação do usuário e token, quando a API fornecer um.
/// A API atual do projeto usa login web por sessão e ainda não expõe JWT/API login.
class SessionManager {
  SessionManager._();
  static final SessionManager instance = SessionManager._();
  static const _storage = FlutterSecureStorage();
  static const _userKey = 'usuario_sessao';
  static const _tokenKey = 'access_token';

  Future<void> salvarUsuario(Usuario usuario) =>
      _storage.write(key: _userKey, value: jsonEncode(usuario.toJson()));

  Future<Usuario?> obterUsuario() async {
    final value = await _storage.read(key: _userKey);
    if (value == null) return null;
    return Usuario.fromJson(jsonDecode(value) as Map<String, dynamic>);
  }

  Future<void> salvarToken(String token) =>
      _storage.write(key: _tokenKey, value: token);

  Future<String?> obterToken() => _storage.read(key: _tokenKey);

  Future<void> encerrar() async {
    await _storage.delete(key: _userKey);
    await _storage.delete(key: _tokenKey);
  }
}
