import 'dart:convert';
import 'package:http/http.dart' as http;
import 'session_manager.dart';

class ApiException implements Exception {
  final String message;
  final int? statusCode;

  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

class ApiClient {
  /// Altere para 'http://localhost:9093/api' se estiver testando no Windows/Web,
  /// ou 'http://10.0.2.2:9093/api' no Emulador Android,
  /// ou use o IP da sua máquina na rede local para dispositivo físico.
  static String baseUrl = 'http://10.82.139.109:9093/api';

  static Future<Map<String, String>> _headers({bool hasBody = false}) async {
    final token = await SessionManager.instance.obterToken();
    final headers = <String, String>{
      'Accept': 'application/json',
    };

    if (hasBody) {
      headers['Content-Type'] = 'application/json';
    }

    if (token != null && token.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }

    return headers;
  }

  static Future<dynamic> get(String endpoint) async {
    final headers = await _headers();
    final response = await http.get(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      if (response.statusCode == 401) {
        throw ApiException(
          'Acesso não autorizado (HTTP 401). Faça login novamente.',
          statusCode: 401,
        );
      }
      throw ApiException(
        'Erro na API: HTTP ${response.statusCode}',
        statusCode: response.statusCode,
      );
    }

    try {
      return jsonDecode(response.body);
    } on FormatException {
      throw ApiException(
        'A API retornou uma resposta JSON inválida.',
        statusCode: response.statusCode,
      );
    }
  }

  static Future<dynamic> post(
    String endpoint, {
    Map<String, dynamic>? body,
  }) async {
    final headers = await _headers(hasBody: true);
    final response = await http.post(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
      body: body == null ? null : jsonEncode(body),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      if (response.statusCode == 401) {
        throw ApiException(
          'Acesso não autorizado (HTTP 401). Verifique suas credenciais.',
          statusCode: 401,
        );
      }
      throw ApiException(
        'Erro na API: HTTP ${response.statusCode}',
        statusCode: response.statusCode,
      );
    }

    if (response.body.isEmpty) return null;

    try {
      return jsonDecode(response.body);
    } on FormatException {
      throw ApiException(
        'A API retornou uma resposta JSON inválida.',
        statusCode: response.statusCode,
      );
    }
  }
}
