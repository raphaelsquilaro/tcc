import 'package:flutter/material.dart';



class AppTheme {

  // =========================================================

  // CORES DO TEMA CLARO: AZUL E BRANCO

  // =========================================================

  static const Color lightPrimary = Color(0xFF0D47A1);      // Azul Cobalto Vibrante

  static const Color lightPrimaryHover = Color(0xFF1565C0);

  static const Color lightSecondary = Color(0xFF0284C7);    // Azul Celeste / Cyan

  static const Color lightBackground = Color(0xFFF8FAFC);   // Branco Gelo / Off-White

  static const Color lightSurface = Color(0xFFFFFFFF);      // Branco Puro

  static const Color lightCard = Color(0xFFFFFFFF);

  static const Color lightBorder = Color(0xFFE2E8F0);       // Borda suave

  static const Color lightTextPrimary = Color(0xFF0F172A);  // Grafite profundo

  static const Color lightTextSecondary = Color(0xFF64748B);// Cinza neutro



  // =========================================================

  // CORES DO TEMA ESCURO: LARANJA E PRETO

  // =========================================================

  static const Color darkPrimary = Color(0xFFFF6D00);       // Laranja Elétrico Vibrante

  static const Color darkPrimaryHover = Color(0xFFFF851A);

  static const Color darkSecondary = Color(0xFFFFA000);     // Laranja Âmbar

  static const Color darkBackground = Color(0xFF0A0A0C);    // Preto Absoluto

  static const Color darkSurface = Color(0xFF121215);       // Preto Grafite

  static const Color darkCard = Color(0xFF18181D);          // Superfície de Cards

  static const Color darkBorder = Color(0xFF27272E);        // Borda sutil escura

  static const Color darkTextPrimary = Color(0xFFFAFAFA);   // Branco puro

  static const Color darkTextSecondary = Color(0xFFA1A1AA); // Cinza fosco



  // =========================================================

  // TEMA CLARO (AZUL E BRANCO)

  // =========================================================

  static ThemeData get lightTheme {

    final colorScheme = ColorScheme.light(

      primary: lightPrimary,

      onPrimary: Colors.white,

      primaryContainer: const Color(0xFFE0E7FF),

      onPrimaryContainer: const Color(0xFF1E3A8A),

      secondary: lightSecondary,

      onSecondary: Colors.white,

      secondaryContainer: const Color(0xFFE0F2FE),

      onSecondaryContainer: const Color(0xFF0369A1),

      surface: lightSurface,

      onSurface: lightTextPrimary,

      error: const Color(0xFFDC2626),

      onError: Colors.white,

      outline: lightBorder,

      outlineVariant: const Color(0xFFCBD5E1),

    );



    return ThemeData(

      useMaterial3: true,

      brightness: Brightness.light,

      colorScheme: colorScheme,

      scaffoldBackgroundColor: lightBackground,

      appBarTheme: const AppBarTheme(

        backgroundColor: lightSurface,

        foregroundColor: lightPrimary,

        elevation: 0,

        centerTitle: false,

        scrolledUnderElevation: 1.5,

        shadowColor: Color(0x1A0D47A1),

        titleTextStyle: TextStyle(

          color: lightTextPrimary,

          fontSize: 20,

          fontWeight: FontWeight.w700,

          letterSpacing: -0.3,

        ),

        iconTheme: IconThemeData(color: lightPrimary),

      ),

      cardTheme: CardThemeData(

        color: lightCard,

        elevation: 1,

        shadowColor: const Color(0x0F0D47A1),

        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.circular(16),

          side: const BorderSide(color: lightBorder, width: 1),

        ),

        margin: EdgeInsets.zero,

      ),

      filledButtonTheme: FilledButtonThemeData(

        style: FilledButton.styleFrom(

          backgroundColor: lightPrimary,

          foregroundColor: Colors.white,

          elevation: 2,

          shadowColor: const Color(0x400D47A1),

          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),

          shape: RoundedRectangleBorder(

            borderRadius: BorderRadius.circular(12),

          ),

          textStyle: const TextStyle(

            fontSize: 15,

            fontWeight: FontWeight.w600,

            letterSpacing: 0.2,

          ),

        ),

      ),

      outlinedButtonTheme: OutlinedButtonThemeData(

        style: OutlinedButton.styleFrom(

          foregroundColor: lightPrimary,

          side: const BorderSide(color: lightPrimary, width: 1.5),

          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),

          shape: RoundedRectangleBorder(

            borderRadius: BorderRadius.circular(12),

          ),

          textStyle: const TextStyle(

            fontSize: 14,

            fontWeight: FontWeight.w600,

          ),

        ),

      ),

      floatingActionButtonTheme: FloatingActionButtonThemeData(

        backgroundColor: lightPrimary,

        foregroundColor: Colors.white,

        elevation: 4,

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),

      ),

      inputDecorationTheme: InputDecorationTheme(

        filled: true,

        fillColor: lightSurface,

        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),

        border: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: lightBorder, width: 1.2),

        ),

        enabledBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: lightBorder, width: 1.2),

        ),

        focusedBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: lightPrimary, width: 2),

        ),

        labelStyle: const TextStyle(color: lightTextSecondary),

        prefixIconColor: lightPrimary,

      ),

      navigationBarTheme: NavigationBarThemeData(

        backgroundColor: lightSurface,

        elevation: 8,

        shadowColor: const Color(0x140D47A1),

        indicatorColor: const Color(0xFFDBEAFE),

        labelTextStyle: WidgetStateProperty.resolveWith((states) {

          if (states.contains(WidgetState.selected)) {

            return const TextStyle(

              fontSize: 12,

              fontWeight: FontWeight.w700,

              color: lightPrimary,

            );

          }

          return const TextStyle(

            fontSize: 12,

            fontWeight: FontWeight.w500,

            color: lightTextSecondary,

          );

        }),

        iconTheme: WidgetStateProperty.resolveWith((states) {

          if (states.contains(WidgetState.selected)) {

            return const IconThemeData(color: lightPrimary, size: 24);

          }

          return const IconThemeData(color: lightTextSecondary, size: 24);

        }),

      ),

      dividerTheme: const DividerThemeData(

        color: lightBorder,

        thickness: 1,

        space: 1,

      ),

    );

  }



  // =========================================================

  // TEMA ESCURO (LARANJA E PRETO)

  // =========================================================

  static ThemeData get darkTheme {

    final colorScheme = ColorScheme.dark(

      primary: darkPrimary,

      onPrimary: Colors.black,

      primaryContainer: const Color(0xFF3B1A00),

      onPrimaryContainer: const Color(0xFFFFD180),

      secondary: darkSecondary,

      onSecondary: Colors.black,

      secondaryContainer: const Color(0xFF2E1900),

      onSecondaryContainer: const Color(0xFFFFE082),

      surface: darkSurface,

      onSurface: darkTextPrimary,

      error: const Color(0xFFEF4444),

      onError: Colors.white,

      outline: darkBorder,

      outlineVariant: const Color(0xFF3F3F46),

    );



    return ThemeData(

      useMaterial3: true,

      brightness: Brightness.dark,

      colorScheme: colorScheme,

      scaffoldBackgroundColor: darkBackground,

      appBarTheme: const AppBarTheme(

        backgroundColor: darkSurface,

        foregroundColor: darkPrimary,

        elevation: 0,

        centerTitle: false,

        scrolledUnderElevation: 1.5,

        shadowColor: Color(0x33000000),

        titleTextStyle: TextStyle(

          color: darkTextPrimary,

          fontSize: 20,

          fontWeight: FontWeight.w700,

          letterSpacing: -0.3,

        ),

        iconTheme: IconThemeData(color: darkPrimary),

      ),

      cardTheme: CardThemeData(

        color: darkCard,

        elevation: 2,

        shadowColor: const Color(0x40000000),

        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.circular(16),

          side: const BorderSide(color: darkBorder, width: 1),

        ),

        margin: EdgeInsets.zero,

      ),

      filledButtonTheme: FilledButtonThemeData(

        style: FilledButton.styleFrom(

          backgroundColor: darkPrimary,

          foregroundColor: Colors.black,

          elevation: 3,

          shadowColor: const Color(0x55FF6D00),

          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),

          shape: RoundedRectangleBorder(

            borderRadius: BorderRadius.circular(12),

          ),

          textStyle: const TextStyle(

            fontSize: 15,

            fontWeight: FontWeight.w700,

            letterSpacing: 0.2,

          ),

        ),

      ),

      outlinedButtonTheme: OutlinedButtonThemeData(

        style: OutlinedButton.styleFrom(

          foregroundColor: darkPrimary,

          side: const BorderSide(color: darkPrimary, width: 1.5),

          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),

          shape: RoundedRectangleBorder(

            borderRadius: BorderRadius.circular(12),

          ),

          textStyle: const TextStyle(

            fontSize: 14,

            fontWeight: FontWeight.w700,

          ),

        ),

      ),

      floatingActionButtonTheme: FloatingActionButtonThemeData(

        backgroundColor: darkPrimary,

        foregroundColor: Colors.black,

        elevation: 5,

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),

      ),

      inputDecorationTheme: InputDecorationTheme(

        filled: true,

        fillColor: darkSurface,

        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),

        border: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: darkBorder, width: 1.2),

        ),

        enabledBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: darkBorder, width: 1.2),

        ),

        focusedBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),

          borderSide: const BorderSide(color: darkPrimary, width: 2),

        ),

        labelStyle: const TextStyle(color: darkTextSecondary),

        prefixIconColor: darkPrimary,

      ),

      navigationBarTheme: NavigationBarThemeData(

        backgroundColor: darkSurface,

        elevation: 8,

        shadowColor: const Color(0x33000000),

        indicatorColor: const Color(0x33FF6D00),

        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: darkPrimary,
            );
          }
          return const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: darkTextSecondary,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const IconThemeData(color: darkPrimary, size: 24);
          }
          return const IconThemeData(color: darkTextSecondary, size: 24);
        }),
      ),
      dividerTheme: const DividerThemeData(
        color: darkBorder,
        thickness: 1,
        space: 1,
      ),
    );
  }
}
