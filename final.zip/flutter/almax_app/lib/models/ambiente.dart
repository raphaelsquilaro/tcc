
class Ambiente {
  final int id;
  final String nome;
  final String descricao;
  final bool ativo;
  final int quantidadeProdutos;
  final int quantidadeLeitores;

  Ambiente({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.ativo,
    required this.quantidadeProdutos,
    required this.quantidadeLeitores,
  });

  factory Ambiente.fromJson(Map<String, dynamic> json) {
    return Ambiente(
      id: (json['id'] as num?)?.toInt() ?? 0,
      nome: json['nome'] as String? ?? '',
      descricao: json['descricao'] as String? ?? '',
      ativo: json['ativo'] as bool? ?? false,
      quantidadeProdutos:
          (json['quantidadeProdutos'] as num?)?.toInt() ?? 0,
      quantidadeLeitores:
          (json['quantidadeLeitores'] as num?)?.toInt() ?? 0,
    );
  }
}
