import 'produto.dart';

enum ResultadoConferencia { conferido, codigoNaoEncontrado, ambienteDivergente, duplicado }

class Conferencia {
  Conferencia({
    required this.codigoLido,
    required this.dataHora,
    required this.resultado,
    this.produto,
    this.mensagem,
  });

  final String codigoLido;
  final DateTime dataHora;
  final ResultadoConferencia resultado;
  final Produto? produto;
  final String? mensagem;

  bool get valida => resultado == ResultadoConferencia.conferido;
}
