class Produto {
  const Produto({
    required this.id,
    required this.numeroPatrimonio,
    required this.nome,
    this.descricao,
    this.marca,
    this.modelo,
    this.numeroSerie,
    this.status,
    this.ambienteId,
    this.ambienteNome,
    this.tagId,
    this.tagEpc,
  });

  final int id;
  final String numeroPatrimonio;
  final String nome;
  final String? descricao;
  final String? marca;
  final String? modelo;
  final String? numeroSerie;
  final String? status;
  final int? ambienteId;
  final String? ambienteNome;
  final int? tagId;
  final String? tagEpc;

  factory Produto.fromJson(Map<String, dynamic> json) => Produto(
        id: (json['id'] as num).toInt(),
        numeroPatrimonio: json['numeroPatrimonio']?.toString() ?? '',
        nome: json['nome']?.toString() ?? '',
        descricao: json['descricao']?.toString(),
        marca: json['marca']?.toString(),
        modelo: json['modelo']?.toString(),
        numeroSerie: json['numeroSerie']?.toString(),
        status: json['status']?.toString(),
        ambienteId: (json['ambienteId'] as num?)?.toInt(),
        ambienteNome: json['ambienteNome']?.toString(),
        tagId: (json['tagId'] as num?)?.toInt(),
        tagEpc: json['tagEpc']?.toString(),
      );
}
