class Usuario {
  const Usuario({
    required this.id,
    required this.nome,
    required this.email,
    required this.ativo,
    required this.perfil,
  });

  final int id;
  final String nome;
  final String email;
  final bool ativo;
  final String perfil;

  factory Usuario.fromJson(Map<String, dynamic> json) => Usuario(
        id: (json['id'] as num).toInt(),
        nome: json['nome']?.toString() ?? '',
        email: json['email']?.toString() ?? '',
        ativo: json['ativo'] == true,
        perfil: json['perfil']?.toString() ?? 'OPERADOR',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'nome': nome,
        'email': email,
        'ativo': ativo,
        'perfil': perfil,
      };
}
