(() => {
    const themeKey = "almax-theme";
    const themes = ["claro", "escuro"];

    function readTheme() {
        try {
            const savedTheme = window.localStorage.getItem(themeKey);
            return themes.includes(savedTheme) ? savedTheme : "claro";
        } catch {
            return "claro";
        }
    }

    function applyTheme(theme) {
        const selectedTheme = themes.includes(theme) ? theme : "claro";
        document.documentElement.dataset.theme = selectedTheme;

        document.querySelectorAll("[data-theme-option]").forEach(button => {
            const isSelected = button.dataset.themeOption === selectedTheme;
            button.setAttribute("aria-pressed", String(isSelected));
            button.classList.toggle("is-selected", isSelected);
        });
    }

    applyTheme(readTheme());

    document.addEventListener("click", event => {
        const button = event.target.closest("[data-theme-option]");
        if (!button) {
            return;
        }

        const theme = button.dataset.themeOption;
        applyTheme(theme);
        try {
            window.localStorage.setItem(themeKey, theme);
        } catch {
            // The chosen theme remains active for the current page.
        }
    });
})();
