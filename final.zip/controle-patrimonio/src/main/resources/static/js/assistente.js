document.addEventListener("DOMContentLoaded", () => {
    const assistant = document.querySelector(".assistant");
    const panel = document.getElementById("assistantPanel");
    const launcher = document.getElementById("assistantLauncher");
    const closeButton = document.getElementById("assistantClose");
    const form = document.getElementById("assistantForm");
    const questionInput = document.getElementById("assistantQuestion");
    const messages = document.getElementById("assistantMessages");
    const status = document.getElementById("assistantStatus");
    const sendButton = document.getElementById("assistantSend");
    const csrfToken = document.querySelector('meta[name="_csrf"]')?.content;
    const csrfHeader = document.querySelector('meta[name="_csrf_header"]')?.content;
    const history = [];

    const setOpen = (open) => {
        assistant.dataset.open = String(open);
        panel.setAttribute("aria-hidden", String(!open));
        panel.inert = !open;
        launcher.setAttribute("aria-expanded", String(open));
        if (open) {
            questionInput.focus();
        } else {
            launcher.focus();
        }
    };

    const appendMessage = (text, role, error = false) => {
        const message = document.createElement("p");
        message.className = `assistant-message assistant-message--${error ? "error" : role}`;
        message.textContent = text;
        messages.append(message);
        messages.scrollTop = messages.scrollHeight;
    };

    launcher.addEventListener("click", () => {
        setOpen(assistant.dataset.open !== "true");
    });
    closeButton.addEventListener("click", () => setOpen(false));
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && assistant.dataset.open === "true") {
            setOpen(false);
        }
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const pergunta = questionInput.value.trim();
        if (!pergunta || sendButton.disabled) {
            return;
        }

        appendMessage(pergunta, "user");
        history.push({ papel: "USER", conteudo: pergunta });
        history.splice(0, Math.max(0, history.length - 8));
        questionInput.value = "";
        sendButton.disabled = true;
        questionInput.disabled = true;
        status.textContent = "Consultando os dados atuais...";

        try {
            const headers = { "Content-Type": "application/json" };
            if (csrfToken && csrfHeader) {
                headers[csrfHeader] = csrfToken;
            }
            const response = await fetch("/api/assistente/chat", {
                method: "POST",
                headers,
                body: JSON.stringify({ pergunta, historico: history.slice(0, -1) }),
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok) {
                throw new Error(payload.message || "Não foi possível obter uma resposta.");
            }

            appendMessage(payload.resposta, "bot");
            history.push({ papel: "ASSISTANT", conteudo: payload.resposta });
            history.splice(0, Math.max(0, history.length - 8));
            status.textContent = "";
        } catch (error) {
            appendMessage(error.message || "O assistente está indisponível. Tente novamente.", "bot", true);
            history.pop();
            status.textContent = "";
        } finally {
            sendButton.disabled = false;
            questionInput.disabled = false;
            questionInput.focus();
        }
    });
});