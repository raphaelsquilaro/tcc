package sp.senai.org.controlepatrimonio.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record AssistenteMensagemRequest(
        @NotBlank(message = "O papel da mensagem é obrigatório")
        @Pattern(regexp = "USER|ASSISTANT", message = "Papel de mensagem inválido")
        String papel,
        @NotBlank(message = "O conteúdo da mensagem não pode estar vazio")
        @Size(max = 1000, message = "A mensagem deve ter no máximo 1000 caracteres")
        String conteudo
) {
}