
package sp.senai.org.controlepatrimonio.controller.api;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import sp.senai.org.controlepatrimonio.dto.request.LoginRequest;
import sp.senai.org.controlepatrimonio.dto.response.LoginResponse;
import sp.senai.org.controlepatrimonio.model.entity.Usuario;
import sp.senai.org.controlepatrimonio.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class ApiAuthController {

    private final AuthenticationManager authenticationManager;
    private final UsuarioRepository usuarioRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody LoginRequest request) {

        System.out.println(">>> ENTROU NO CONTROLLER DE LOGIN");

        try {
            Authentication authentication =
                    authenticationManager.authenticate(
                            new UsernamePasswordAuthenticationToken(
                                    request.email(),
                                    request.senha()
                            )
                    );

            Usuario usuario = usuarioRepository
                    .findByEmail(authentication.getName())
                    .orElseThrow();

            return ResponseEntity.ok(new LoginResponse(
                    usuario.getId(),
                    usuario.getNome(),
                    usuario.getEmail(),
                    usuario.getPerfil().name()
            ));

        } catch (org.springframework.security.core.AuthenticationException e) {
            System.err.println(
                    "Falha na autenticação: " + e.getClass().getSimpleName()
            );

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(java.util.Map.of(
                            "erro", "E-mail ou senha inválidos."
                    ));
        }
    }
}
