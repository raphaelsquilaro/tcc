package sp.senai.org.controlepatrimonio.service;

public enum AssistenteIntencao {
    RESUMO,
    PRODUTO,
    AMBIENTE,
    MOVIMENTACOES
}