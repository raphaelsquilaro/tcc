package sp.senai.org.controlepatrimonio.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.util.List;

public record AssistentePerguntaRequest(
        @NotBlank(message = "A pergunta não pode estar vazia")
        @Size(max = 1500, message = "A pergunta deve ter no máximo 1500 caracteres")
        String pergunta,
        @Size(max = 8, message = "O histórico deve ter no máximo 8 mensagens")
        List<@Valid AssistenteMensagemRequest> historico
) {
}