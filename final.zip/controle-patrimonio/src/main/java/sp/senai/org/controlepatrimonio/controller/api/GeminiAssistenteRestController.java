package sp.senai.org.controlepatrimonio.controller.api;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sp.senai.org.controlepatrimonio.dto.request.AssistentePerguntaRequest;
import sp.senai.org.controlepatrimonio.dto.response.AssistenteResposta;
import sp.senai.org.controlepatrimonio.service.AssistenteRateLimiter;
import sp.senai.org.controlepatrimonio.service.AssistenteService;

import java.security.Principal;

@RestController
@RequestMapping("/api/assistente")
@RequiredArgsConstructor
public class GeminiAssistenteRestController {

    private final AssistenteService assistenteService;
    private final AssistenteRateLimiter rateLimiter;

    @PostMapping("/chat")
    public ResponseEntity<AssistenteResposta> perguntar(
            @Valid @RequestBody AssistentePerguntaRequest request,
            Principal principal
    ) {
        rateLimiter.verificar(principal.getName());
        return ResponseEntity.ok(new AssistenteResposta(
                assistenteService.responder(request.pergunta(), request.historico())
        ));
    }
}