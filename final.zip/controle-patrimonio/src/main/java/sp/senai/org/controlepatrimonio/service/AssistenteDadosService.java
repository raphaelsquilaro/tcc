package sp.senai.org.controlepatrimonio.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import sp.senai.org.controlepatrimonio.model.entity.Ambiente;
import sp.senai.org.controlepatrimonio.model.entity.Movimentacao;
import sp.senai.org.controlepatrimonio.model.entity.Produto;
import sp.senai.org.controlepatrimonio.model.enums.StatusProduto;
import sp.senai.org.controlepatrimonio.repository.AmbienteRepository;
import sp.senai.org.controlepatrimonio.repository.LeitorRepository;
import sp.senai.org.controlepatrimonio.repository.MovimentacaoRepository;
import sp.senai.org.controlepatrimonio.repository.ProdutoRepository;
import sp.senai.org.controlepatrimonio.repository.TagRepository;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Map;

@Service
public class AssistenteDadosService {

    private final ProdutoRepository produtoRepository;
    private final AmbienteRepository ambienteRepository;
    private final TagRepository tagRepository;
    private final LeitorRepository leitorRepository;
    private final MovimentacaoRepository movimentacaoRepository;
    private final ObjectMapper objectMapper;

    public AssistenteDadosService(
            ProdutoRepository produtoRepository,
            AmbienteRepository ambienteRepository,
            TagRepository tagRepository,
            LeitorRepository leitorRepository,
            MovimentacaoRepository movimentacaoRepository,
            ObjectMapper objectMapper
    ) {
        this.produtoRepository = produtoRepository;
        this.ambienteRepository = ambienteRepository;
        this.tagRepository = tagRepository;
        this.leitorRepository = leitorRepository;
        this.movimentacaoRepository = movimentacaoRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional(readOnly = true)
    public String consultar(AssistenteIntencao intencao, String filtro) {
        String valorFiltro = limitarFiltro(filtro);
        return switch (intencao) {
            case PRODUTO -> produtos(valorFiltro);
            case AMBIENTE -> ambiente(valorFiltro);
            case MOVIMENTACOES -> serializar(Map.of("movimentacoesRecentes", movimentosRecentes()));
            case RESUMO -> resumo();
        };
    }

    private String resumo() {
        return serializar(Map.of(
                "produtos", produtoRepository.count(),
                "produtosAtivos", produtoRepository.countByStatus(StatusProduto.ATIVO),
                "produtosInativos", produtoRepository.countByStatus(StatusProduto.INATIVO),
                "produtosComTag", produtoRepository.countByTagIsNotNull(),
                "ambientes", ambienteRepository.count(),
                "tags", tagRepository.count(),
                "leitores", leitorRepository.count(),
                "movimentacoesRecentes", movimentosRecentes()
        ));
    }

    private String produtos(String filtro) {
        if (filtro.isBlank()) {
            return resumo();
        }

        List<Map<String, Object>> encontrados = produtoRepository
                .findTop5ByNomeContainingIgnoreCaseOrNumeroPatrimonioContainingIgnoreCaseOrderByNomeAsc(
                        filtro,
                        filtro
                )
                .stream()
                .map(this::resumirProduto)
                .toList();
        return serializar(Map.of("produtosEncontrados", encontrados));
    }

    private String ambiente(String filtro) {
        if (filtro.isBlank()) {
            return resumo();
        }

        return ambienteRepository.findByNomeIgnoreCase(filtro)
                .<String>map(ambiente -> serializar(Map.of(
                        "ambiente", ambiente.getNome(),
                        "ativo", ambiente.getAtivo(),
                        "produtos", produtoRepository.countByAmbienteNomeIgnoreCase(ambiente.getNome())
                )))
                .orElseGet(() -> serializar(Map.of(
                        "ambientePesquisado", filtro,
                        "encontrado", false
                )));
    }

    private List<Map<String, Object>> movimentosRecentes() {
        return movimentacaoRepository.findTop10ByOrderByDataHoraDesc()
                .stream()
                .map(this::resumirMovimentacao)
                .toList();
    }

    private Map<String, Object> resumirProduto(Produto produto) {
        return Map.of(
                "patrimonio", produto.getNumeroPatrimonio(),
                "nome", produto.getNome(),
                "status", produto.getStatus().name(),
                "ambiente", produto.getAmbiente() == null
                        ? "Sem ambiente"
                        : produto.getAmbiente().getNome()
        );
    }

    private Map<String, Object> resumirMovimentacao(Movimentacao movimentacao) {
        return Map.of(
                "produto", movimentacao.getProduto().getNome(),
                "origem", movimentacao.getAmbienteOrigem() == null
                        ? "Não informado"
                        : movimentacao.getAmbienteOrigem().getNome(),
                "destino", movimentacao.getAmbienteDestino() == null
                        ? "Não informado"
                        : movimentacao.getAmbienteDestino().getNome(),
                "dataHora", movimentacao.getDataHora().toString()
        );
    }

    private String limitarFiltro(String filtro) {
        if (!StringUtils.hasText(filtro)) {
            return "";
        }
        String valor = filtro.trim();
        return valor.substring(0, Math.min(valor.length(), 100));
    }

    private String serializar(Object dados) {
        try {
            return objectMapper.writeValueAsString(dados);
        } catch (JacksonException exception) {
            return "{}";
        }
    }
}