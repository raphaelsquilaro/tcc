package sp.senai.org.controlepatrimonio.exception;

public class AssistenteLimiteExcedidoException extends RuntimeException {

    public AssistenteLimiteExcedidoException() {
        super("Limite de perguntas atingido. Aguarde um minuto para tentar novamente.");
    }
}