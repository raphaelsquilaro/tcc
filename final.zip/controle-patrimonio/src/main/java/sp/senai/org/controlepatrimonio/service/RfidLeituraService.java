package sp.senai.org.controlepatrimonio.service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import sp.senai.org.controlepatrimonio.dto.request.LeituraRfidRequest;
import sp.senai.org.controlepatrimonio.dto.response.RfidLeituraEventoResponse;
import sp.senai.org.controlepatrimonio.model.entity.RfidLeitura;
import sp.senai.org.controlepatrimonio.repository.RfidLeituraRepository;

import java.util.Optional;

@Service
@AllArgsConstructor
public class RfidLeituraService {

    private final RfidLeituraRepository repository;

    @Transactional
    public RfidLeitura salvar(LeituraRfidRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Body da requisição inválido.");
        }

        if (request.uid() == null || request.uid().isBlank()) {
            throw new IllegalArgumentException("Campo uid obrigatório.");
        }

        if (request.deviceId() == null || request.deviceId().isBlank()) {
            throw new IllegalArgumentException("Campo deviceId obrigatório.");
        }

        RfidLeitura leitura = new RfidLeitura();
        leitura.setUid(request.uid().trim().toUpperCase());
        leitura.setDeviceId(request.deviceId().trim());
        leitura.setDataHora(java.time.LocalDateTime.now());

        return repository.save(leitura);
    }

    @Transactional
    public Long cursorAtual() {
        return repository.findTopByOrderByIdDesc()
                .map(RfidLeitura::getId)
                .orElse(0L);
    }

    @Transactional
    public Optional<RfidLeituraEventoResponse> buscarProximaLeitura(Long aposId) {
        if (aposId == null || aposId < 0) {
            throw new IllegalArgumentException("O identificador da última leitura é inválido.");
        }

        return repository.findFirstByIdGreaterThanOrderByIdAsc(aposId)
                .map(leitura -> new RfidLeituraEventoResponse(
                        leitura.getId(),
                        leitura.getUid(),
                        leitura.getDeviceId(),
                        leitura.getDataHora()
                ));
    }
}
