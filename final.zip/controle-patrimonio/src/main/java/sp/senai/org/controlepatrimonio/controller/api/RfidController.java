package sp.senai.org.controlepatrimonio.controller.api;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sp.senai.org.controlepatrimonio.dto.request.LeituraRfidRequest;
import sp.senai.org.controlepatrimonio.model.entity.RfidLeitura;
import sp.senai.org.controlepatrimonio.service.RfidLeituraService;

@RestController
@RequestMapping("/api/rfid")
@RequiredArgsConstructor
public class RfidController {

    private final RfidLeituraService rfidService;

    @GetMapping("/leituras/cursor")
    public ResponseEntity<Long> cursorLeituras() {
        return ResponseEntity.ok(rfidService.cursorAtual());
    }

    @GetMapping("/leituras/novas")
    public ResponseEntity<?> novasLeituras(
            @RequestParam Long aposId
    ) {
        return rfidService.buscarProximaLeitura(aposId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.noContent().build());
    }

    @PostMapping("/leitura")
    public ResponseEntity<?> receberLeitura(@RequestBody LeituraRfidRequest request) {
        try {
            RfidLeitura salva = rfidService.salvar(request);
            return ResponseEntity.ok(
                    "Leitura salva com sucesso: " + salva.getUid()
            );
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Erro ao salvar leitura: " + e.getMessage());
        }
    }
}
