package sp.senai.org.controlepatrimonio.service;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import sp.senai.org.controlepatrimonio.config.GeminiProperties;
import sp.senai.org.controlepatrimonio.exception.GeminiIndisponivelException;
import tools.jackson.databind.JsonNode;

import java.util.List;
import java.util.Map;

@Component
public class GeminiClient {

    private final RestClient restClient;
    private final GeminiProperties properties;

    public GeminiClient(RestClient geminiRestClient, GeminiProperties properties) {
        this.restClient = geminiRestClient;
        this.properties = properties;
    }

    public String gerarTexto(String instrucao, String entrada, boolean json) {
        if (properties.getApiKey() == null || properties.getApiKey().isBlank()) {
            throw new GeminiIndisponivelException();
        }

        Map<String, Object> generationConfig = json
                ? Map.of(
                        "temperature", 0,
                        "maxOutputTokens", 256,
                        "responseMimeType", "application/json"
                )
                : Map.of("temperature", 0.2, "maxOutputTokens", 700);
        Map<String, Object> payload = Map.of(
                "systemInstruction", Map.of(
                        "parts", List.of(Map.of("text", instrucao))
                ),
                "contents", List.of(Map.of(
                        "role", "user",
                        "parts", List.of(Map.of("text", entrada))
                )),
                "generationConfig", generationConfig
        );

        try {
            JsonNode response = restClient.post()
                    .uri("/v1beta/models/{model}:generateContent", properties.getModel())
                    .header("x-goog-api-key", properties.getApiKey())
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(payload)
                    .retrieve()
                    .body(JsonNode.class);
            JsonNode text = response == null
                    ? null
                    : response.path("candidates").path(0)
                            .path("content").path("parts").path(0).path("text");

            if (text == null || !text.isTextual() || text.asText().isBlank()) {
                throw new GeminiIndisponivelException();
            }
            return text.asText();
        } catch (RestClientException exception) {
            throw new GeminiIndisponivelException();
        }
    }
}