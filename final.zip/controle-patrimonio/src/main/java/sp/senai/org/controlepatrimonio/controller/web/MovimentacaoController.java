package sp.senai.org.controlepatrimonio.controller.web;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import sp.senai.org.controlepatrimonio.dto.request.MovimentacaoRequest;
import sp.senai.org.controlepatrimonio.model.entity.Produto;
import sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao;
import sp.senai.org.controlepatrimonio.repository.ProdutoRepository;
import sp.senai.org.controlepatrimonio.service.*;

@Controller
@RequestMapping("/movimentacoes")
@RequiredArgsConstructor
public class MovimentacaoController {

    private final MovimentacaoService movimentacaoService;
    private final ProdutoService produtoService;
    private final AmbienteService ambienteService;
    private final LeitorService leitorService;
    private final UsuarioService usuarioService;
    private final ProdutoRepository produtoRepository;
    private final RfidLeituraService rfidLeituraService;


    @GetMapping
    public String listar(Model model) {

        model.addAttribute(
                "movimentacoes",
                movimentacaoService.listar()
        );

        return "movimentacoes/lista";
    }


    @GetMapping("/novo")
    public String nova(Model model) {

        model.addAttribute(
                "movimentacaoRequest",
                new MovimentacaoRequest(
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                )
        );

        carregarDados(model);

        return "movimentacoes/formulario";
    }

    @GetMapping("/por-tag")
    public String novaPorTag(Model model) {
        model.addAttribute("tagEpc", "");
        model.addAttribute("rfidCursor", rfidLeituraService.cursorAtual());
        model.addAttribute("ambientes", ambienteService.listar());
        model.addAttribute("leitores", leitorService.listar());
        model.addAttribute("usuarios", usuarioService.listar());
        return "movimentacoes/por-tag";
    }

    @PostMapping("/por-tag")
    public String registrarPorTag(
            @RequestParam String tagEpc,
            @RequestParam(required = false) Long ambienteDestinoId,
            @RequestParam(required = false) Long leitorId,
            @RequestParam(required = false) Long usuarioId,
            @RequestParam(required = false) String observacao,
            RedirectAttributes redirectAttributes,
            Model model
    ) {
        try {
            if (tagEpc == null || tagEpc.isBlank()) {
                throw new IllegalArgumentException("Informe a tag RFID.");
            }

            Produto produto = produtoRepository.findByTag_EpcIgnoreCase(tagEpc.trim())
                    .orElseThrow(() -> new IllegalArgumentException("Tag RFID não vinculada a nenhum produto."));

            MovimentacaoRequest request = new MovimentacaoRequest(
                    produto.getId(),
                    produto.getAmbiente() != null ? produto.getAmbiente().getId() : null,
                    ambienteDestinoId,
                    leitorId,
                    usuarioId,
                    TipoMovimentacao.LEITURA_RFID,
                    java.time.LocalDate.now(),
                    observacao != null ? observacao : "Movimentação registrada por leitura de tag RFID."
            );

            movimentacaoService.criar(request);
            redirectAttributes.addFlashAttribute("sucesso", "Movimentação por tag registrada com sucesso!");
            return "redirect:/movimentacoes";
        } catch (Exception e) {
            model.addAttribute("erro", e.getMessage());
            model.addAttribute("tagEpc", tagEpc);
            model.addAttribute("rfidCursor", rfidLeituraService.cursorAtual());
            model.addAttribute("ambientes", ambienteService.listar());
            model.addAttribute("leitores", leitorService.listar());
            model.addAttribute("usuarios", usuarioService.listar());
            return "movimentacoes/por-tag";
        }
    }


    @PostMapping
    public String criar(
            @Valid
            @ModelAttribute("movimentacaoRequest")
            MovimentacaoRequest request,

            BindingResult bindingResult,

            Model model
    ) {

        if (bindingResult.hasErrors()) {

            carregarDados(model);

            return "movimentacoes/formulario";
        }

        movimentacaoService.criar(request);

        return "redirect:/movimentacoes";
    }


    @GetMapping("/{id}")
    public String detalhes(
            @PathVariable Long id,
            Model model
    ) {

        model.addAttribute(
                "movimentacao",
                movimentacaoService.buscarPorId(id)
        );

        return "movimentacoes/detalhes";
    }


    private void carregarDados(Model model) {

        model.addAttribute(
                "produtos",
                produtoService.listar()
        );

        model.addAttribute(
                "ambientes",
                ambienteService.listar()
        );

        model.addAttribute(
                "leitores",
                leitorService.listar()
        );

        model.addAttribute(
                "usuarios",
                usuarioService.listar()
        );

        model.addAttribute(
                "tiposMovimentacao",
                new sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao[] {
                        sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao.ENTRADA,
                        sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao.SAIDA,
                        sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao.TRANSFERENCIA,
                        sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao.AJUSTE
                }
        );
    }
}