package sp.senai.org.controlepatrimonio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sp.senai.org.controlepatrimonio.model.entity.RfidLeitura;

import java.util.Optional;

public interface RfidLeituraRepository extends JpaRepository<RfidLeitura, Long> {

    Optional<RfidLeitura> findFirstByIdGreaterThanOrderByIdAsc(Long id);

    Optional<RfidLeitura> findTopByOrderByIdDesc();
}
