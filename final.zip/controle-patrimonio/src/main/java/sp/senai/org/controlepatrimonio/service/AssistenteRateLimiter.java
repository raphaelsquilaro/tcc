package sp.senai.org.controlepatrimonio.service;

import org.springframework.stereotype.Component;
import sp.senai.org.controlepatrimonio.exception.AssistenteLimiteExcedidoException;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class AssistenteRateLimiter {

    private static final int MAX_REQUESTS = 12;
    private static final long WINDOW_SECONDS = 60;
    private final ConcurrentHashMap<String, ArrayDeque<Instant>> requests = new ConcurrentHashMap<>();

    public void verificar(String usuario) {
        ArrayDeque<Instant> usuarioRequests = requests.computeIfAbsent(
                usuario,
                ignored -> new ArrayDeque<>()
        );
        synchronized (usuarioRequests) {
            Instant limite = Instant.now().minusSeconds(WINDOW_SECONDS);
            while (!usuarioRequests.isEmpty() && usuarioRequests.peekFirst().isBefore(limite)) {
                usuarioRequests.removeFirst();
            }
            if (usuarioRequests.size() >= MAX_REQUESTS) {
                throw new AssistenteLimiteExcedidoException();
            }
            usuarioRequests.addLast(Instant.now());
        }
    }
}