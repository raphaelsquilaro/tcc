package sp.senai.org.controlepatrimonio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sp.senai.org.controlepatrimonio.model.entity.Ambiente;

import java.util.Optional;

public interface AmbienteRepository
        extends JpaRepository<Ambiente, Long> {

        Optional<Ambiente> findByNomeIgnoreCase(String nome);
}
