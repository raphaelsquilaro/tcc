package sp.senai.org.controlepatrimonio.exception;

public class GeminiIndisponivelException extends RuntimeException {

    public GeminiIndisponivelException() {
        super("O assistente está temporariamente indisponível. Tente novamente em instantes.");
    }
}