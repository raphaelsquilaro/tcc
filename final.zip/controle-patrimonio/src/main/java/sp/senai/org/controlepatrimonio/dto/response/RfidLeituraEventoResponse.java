package sp.senai.org.controlepatrimonio.dto.response;

import java.time.LocalDateTime;

public record RfidLeituraEventoResponse(
        Long id,
        String uid,
        String deviceId,
        LocalDateTime dataHora
) {
}
