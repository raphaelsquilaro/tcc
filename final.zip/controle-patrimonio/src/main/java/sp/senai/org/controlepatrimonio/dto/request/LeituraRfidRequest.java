package sp.senai.org.controlepatrimonio.dto.request;

import com.fasterxml.jackson.annotation.JsonAlias;

public record LeituraRfidRequest(
        @JsonAlias({"epc", "tag", "tagEpc"})
        String uid,
        @JsonAlias({"device_id", "deviceID", "readerId", "identificador"})
        String deviceId
) {
}
