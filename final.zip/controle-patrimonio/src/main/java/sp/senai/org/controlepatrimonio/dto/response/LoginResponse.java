package sp.senai.org.controlepatrimonio.dto.response;

public record LoginResponse(
        Long id,
        String nome,
        String email,
        String perfil
) {}