package sp.senai.org.controlepatrimonio.dto.response;

public record AssistenteResposta(String resposta) {
}