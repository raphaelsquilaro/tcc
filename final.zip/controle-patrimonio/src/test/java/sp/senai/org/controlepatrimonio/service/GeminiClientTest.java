package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;
import sp.senai.org.controlepatrimonio.config.GeminiProperties;
import sp.senai.org.controlepatrimonio.exception.GeminiIndisponivelException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

class GeminiClientTest {

    @Test
    void chaveAusenteNaoFazRequisicaoAoProvedor() {
        RestClient restClient = mock(RestClient.class);
        GeminiProperties properties = new GeminiProperties();
        GeminiClient client = new GeminiClient(restClient, properties);

        assertThrows(
                GeminiIndisponivelException.class,
                () -> client.gerarTexto("instrução", "entrada", false)
        );
        verifyNoInteractions(restClient);
    }
}