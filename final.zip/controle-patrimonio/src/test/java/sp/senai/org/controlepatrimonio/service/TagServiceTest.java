package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sp.senai.org.controlepatrimonio.dto.request.TagRequest;
import sp.senai.org.controlepatrimonio.model.entity.Produto;
import sp.senai.org.controlepatrimonio.model.entity.Tag;
import sp.senai.org.controlepatrimonio.repository.ProdutoRepository;
import sp.senai.org.controlepatrimonio.repository.TagRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TagServiceTest {

    @Mock
    private TagRepository tagRepository;

    @Mock
    private ProdutoRepository produtoRepository;

    @InjectMocks
    private TagService tagService;

    @Test
    void deveVincularTagCriadaAoProduto() {
        Produto produto = new Produto();
        produto.setId(5L);
        produto.setNumeroPatrimonio("PAT-5");
        produto.setNome("Notebook");

        when(tagRepository.findByEpc("EPC-123")).thenReturn(Optional.empty());
        when(produtoRepository.findById(5L)).thenReturn(Optional.of(produto));
        when(tagRepository.save(any(Tag.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(produtoRepository.save(any(Produto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        var response = tagService.criar(new TagRequest("EPC-123", null, true, 5L));

        assertEquals(5L, response.produtoId());
        assertEquals("EPC-123", produto.getTag().getEpc());
        assertSame(produto, produto.getTag().getProduto());
        verify(produtoRepository).save(produto);
    }
}
