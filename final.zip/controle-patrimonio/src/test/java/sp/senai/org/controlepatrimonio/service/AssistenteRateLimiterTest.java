package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import sp.senai.org.controlepatrimonio.exception.AssistenteLimiteExcedidoException;

import static org.junit.jupiter.api.Assertions.assertThrows;

class AssistenteRateLimiterTest {

    @Test
    void limitaDozeRequisicoesPorUsuarioEmUmMinuto() {
        AssistenteRateLimiter limiter = new AssistenteRateLimiter();

        for (int tentativa = 0; tentativa < 12; tentativa++) {
            limiter.verificar("operador@exemplo.com");
        }

        assertThrows(
                AssistenteLimiteExcedidoException.class,
                () -> limiter.verificar("operador@exemplo.com")
        );
        limiter.verificar("outro@exemplo.com");
    }
}