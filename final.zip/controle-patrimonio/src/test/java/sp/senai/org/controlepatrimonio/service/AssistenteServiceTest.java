package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import tools.jackson.databind.ObjectMapper;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AssistenteServiceTest {

    @Test
    void responderConsultaSomenteIntencaoPermitidaEUsaDadosAtuais() {
        GeminiClient geminiClient = mock(GeminiClient.class);
        AssistenteDadosService dadosService = mock(AssistenteDadosService.class);
        AssistenteService service = new AssistenteService(
                geminiClient,
                dadosService,
                new ObjectMapper()
        );
        when(geminiClient.gerarTexto(anyString(), anyString(), eq(true)))
                .thenReturn("{\"intencao\":\"PRODUTO\",\"filtro\":\"Notebook\"}");
        when(dadosService.consultar(AssistenteIntencao.PRODUTO, "Notebook"))
                .thenReturn("{\"produtosEncontrados\":[]}");
        when(geminiClient.gerarTexto(anyString(), anyString(), eq(false)))
                .thenReturn("Não encontrei produtos correspondentes.");

        String resposta = service.responder("Quais notebooks estão cadastrados?", List.of());

        assertEquals("Não encontrei produtos correspondentes.", resposta);
        verify(dadosService).consultar(AssistenteIntencao.PRODUTO, "Notebook");
    }

    @Test
    void classificadorInvalidoUsaResumoSemExecutarConsultaDinamica() {
        GeminiClient geminiClient = mock(GeminiClient.class);
        AssistenteDadosService dadosService = mock(AssistenteDadosService.class);
        AssistenteService service = new AssistenteService(
                geminiClient,
                dadosService,
                new ObjectMapper()
        );
        when(geminiClient.gerarTexto(anyString(), anyString(), eq(true)))
                .thenReturn("resposta fora do formato JSON");
        when(dadosService.consultar(AssistenteIntencao.RESUMO, ""))
                .thenReturn("{\"produtos\":0}");
        when(geminiClient.gerarTexto(anyString(), anyString(), eq(false)))
                .thenReturn("Não há produtos cadastrados.");

        String resposta = service.responder("Quantos itens temos?", List.of());

        assertEquals("Não há produtos cadastrados.", resposta);
        verify(dadosService).consultar(AssistenteIntencao.RESUMO, "");
    }

    @Test
    void perguntaMaiorQueLimiteNaoChamaGemini() {
        GeminiClient geminiClient = mock(GeminiClient.class);
        AssistenteDadosService dadosService = mock(AssistenteDadosService.class);
        AssistenteService service = new AssistenteService(
                geminiClient,
                dadosService,
                new ObjectMapper()
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> service.responder("a".repeat(1501), List.of())
        );
        verify(geminiClient, never()).gerarTexto(anyString(), anyString(), any(Boolean.class));
    }
}