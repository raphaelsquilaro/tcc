package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sp.senai.org.controlepatrimonio.dto.request.MovimentacaoRequest;
import sp.senai.org.controlepatrimonio.model.entity.Ambiente;
import sp.senai.org.controlepatrimonio.model.entity.Leitor;
import sp.senai.org.controlepatrimonio.model.entity.Movimentacao;
import sp.senai.org.controlepatrimonio.model.entity.Produto;
import sp.senai.org.controlepatrimonio.model.entity.Usuario;
import sp.senai.org.controlepatrimonio.model.enums.StatusProduto;
import sp.senai.org.controlepatrimonio.model.enums.TipoMovimentacao;
import sp.senai.org.controlepatrimonio.repository.AmbienteRepository;
import sp.senai.org.controlepatrimonio.repository.LeitorRepository;
import sp.senai.org.controlepatrimonio.repository.MovimentacaoRepository;
import sp.senai.org.controlepatrimonio.repository.ProdutoRepository;
import sp.senai.org.controlepatrimonio.repository.UsuarioRepository;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.mockito.ArgumentCaptor;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MovimentacaoServiceTest {

    @Mock
    private MovimentacaoRepository movimentacaoRepository;

    @Mock
    private ProdutoRepository produtoRepository;

    @Mock
    private AmbienteRepository ambienteRepository;

    @Mock
    private LeitorRepository leitorRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private MovimentacaoService movimentacaoService;

    @Test
    void devePermitirSaidaManualSemDestinoElimparAmbienteAtual() {
        Ambiente ambienteOrigem = new Ambiente();
        ambienteOrigem.setId(10L);
        ambienteOrigem.setNome("Almoxarifado");

        Produto produto = new Produto();
        produto.setId(5L);
        produto.setNome("Notebook");
        produto.setStatus(StatusProduto.ATIVO);
        produto.setAmbiente(ambienteOrigem);

        Leitor leitor = new Leitor();
        leitor.setId(7L);
        leitor.setNome("Leitor 01");

        Usuario usuario = new Usuario();
        usuario.setId(9L);
        usuario.setNome("Operador");

        when(produtoRepository.findById(5L)).thenReturn(Optional.of(produto));
        when(leitorRepository.findById(7L)).thenReturn(Optional.of(leitor));
        when(usuarioRepository.findById(9L)).thenReturn(Optional.of(usuario));
        when(movimentacaoRepository.save(any(Movimentacao.class))).thenAnswer(invocation -> {
            Movimentacao movimentacao = invocation.getArgument(0);
            movimentacao.setId(1L);
            return movimentacao;
        });
        when(produtoRepository.save(any(Produto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        MovimentacaoRequest request = new MovimentacaoRequest(
                5L,
                null,
                null,
                7L,
                9L,
                TipoMovimentacao.SAIDA,
                LocalDate.now(),
                "Saída manual"
        );

        movimentacaoService.criar(request);

        assertNull(produto.getAmbiente());

        ArgumentCaptor<Movimentacao> movimentacaoCaptor =
                ArgumentCaptor.forClass(Movimentacao.class);
        verify(movimentacaoRepository).save(movimentacaoCaptor.capture());
        assertEquals(ambienteOrigem, movimentacaoCaptor.getValue().getAmbienteOrigem());
        assertNull(movimentacaoCaptor.getValue().getAmbienteDestino());
    }
}
