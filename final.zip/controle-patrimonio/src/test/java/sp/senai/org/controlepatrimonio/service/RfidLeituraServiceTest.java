package sp.senai.org.controlepatrimonio.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sp.senai.org.controlepatrimonio.model.entity.RfidLeitura;
import sp.senai.org.controlepatrimonio.repository.RfidLeituraRepository;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RfidLeituraServiceTest {

    @Mock
    private RfidLeituraRepository repository;

    @InjectMocks
    private RfidLeituraService service;

    @Test
    void deveRetornarNovaLeituraParaMonitoramentoDaTela() {
        LocalDateTime dataHora = LocalDateTime.now();
        RfidLeitura leitura = new RfidLeitura(12L, "EPC-123", "LEITOR-01", dataHora);
        when(repository.findFirstByIdGreaterThanOrderByIdAsc(10L))
                .thenReturn(Optional.of(leitura));

        var evento = service.buscarProximaLeitura(10L).orElseThrow();

        assertEquals(12L, evento.id());
        assertEquals("EPC-123", evento.uid());
        assertEquals("LEITOR-01", evento.deviceId());
        assertEquals(dataHora, evento.dataHora());
    }

    @Test
    void cursorDeveSerZeroQuandoNaoHaLeituras() {
        when(repository.findTopByOrderByIdDesc()).thenReturn(Optional.empty());

        assertEquals(0L, service.cursorAtual());
    }

    @Test
    void deveRetornarVazioQuandoAindaNaoHaNovaLeitura() {
        when(repository.findFirstByIdGreaterThanOrderByIdAsc(12L))
                .thenReturn(Optional.empty());

        assertTrue(service.buscarProximaLeitura(12L).isEmpty());
    }
}
