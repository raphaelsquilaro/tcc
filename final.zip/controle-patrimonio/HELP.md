# Getting Started

### Reference Documentation

For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.1/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.1/maven-plugin/build-image.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.1.1/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Thymeleaf](https://docs.spring.io/spring-boot/4.1.1/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Validation](https://docs.spring.io/spring-boot/4.1.1/reference/io/validation.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.1/reference/web/servlet.html)

### Guides

The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the
parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

### Assistente patrimonial com Gemini

O botão do assistente fica disponível no dashboard para usuários autenticados. A API é `POST /api/assistente/chat`; as consultas ao banco são somente leitura, feitas por repositórios Spring Data JPA e limitadas a intenções pré-definidas. O modelo não recebe acesso SQL nem credenciais. O endpoint segue a proteção CSRF do Spring Security e aceita perguntas de até 1.500 caracteres, até oito mensagens de histórico e 12 requisições por usuário por minuto.

Configure uma chave da API Gemini no ambiente do processo. No PowerShell:

```powershell
$env:GEMINI_API_KEY = "SUA_CHAVE_GEMINI"
& "$PWD\mvnw.cmd" spring-boot:run
```

`GEMINI_MODEL` seleciona o modelo (padrão `gemini-3.8-flash`) e `GEMINI_TIMEOUT` define o timeout HTTP (padrão `20s`). A chave não deve ser gravada no repositório, enviada ao navegador ou incluída em logs. Sem chave, o endpoint retorna `503` sem chamar o provedor.

O Gemini recebe a pergunta, até oito mensagens recentes e somente o contexto necessário para a consulta: contagens do dashboard, até cinco produtos correspondentes ou até dez movimentações recentes. Valores, números de série, observações, usuários e credenciais não são enviados. O uso da API paga pode gerar cobrança conforme tokens e modelo; consulte a página oficial de [preços do Gemini](https://ai.google.dev/gemini-api/docs/pricing). Não use uma chave do nível gratuito com dados reais do patrimônio.

O limite de requisições é em memória e vale por instância da aplicação; em implantação com múltiplas instâncias, configure também limitação no proxy/gateway. A autorização segue a regra existente do sistema, que requer autenticação e ainda não diferencia as permissões por perfil.

